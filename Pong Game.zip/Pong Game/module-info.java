module pongGP {
	requires java.desktop;
}